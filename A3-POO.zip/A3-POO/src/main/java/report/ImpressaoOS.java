package report;

import domain.OrdemServico;
import domain.Servico;

public class ImpressaoOS {

    public static String ImprimirOS(OrdemServico os){
        StringBuilder impressao = new StringBuilder();
        impressao.append("Serviço: ").append(os.getNumero()).append("\n");
        impressao.append("==============SERVIÇOS - NOTA  ===================").append("\n\n");
        impressao.append("==========================================").append("\n\n");

        return impressao.toString();
    }
}
