package report;

public class Relatorio {
}
