package domain;

public interface IDados {
   
    String getDados();
    String getDados(String observacao);
    
}
