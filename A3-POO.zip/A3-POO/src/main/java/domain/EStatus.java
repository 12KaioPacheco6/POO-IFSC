package domain;

public enum EStatus {
    ABERTA, FECHADA , CANCELADA;
}
