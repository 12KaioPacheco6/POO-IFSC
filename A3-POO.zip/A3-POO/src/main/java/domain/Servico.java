package domain;

import java.util.ArrayList;
import java.util.List;

public class Servico {
    private int id;
    private String descricao;
    private double valor;
    private int pontos;

    private ECategoria categoria = ECategoria.MEDIO;
    private List<ItemOS> itens = new ArrayList<>();

    Servico() {
        this.id = 0;
        this.descricao = null;
        this.valor = 0;
        this.pontos = 0;
    }

    public Servico(int id, String descricao, double valor, int pontos, ECategoria categoria) {
        this.id = id;
        this.descricao = descricao;
        this.valor = valor;
        this.pontos = pontos;
        this.categoria = categoria;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getValor() {
        valor = calcarServico();
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public int getPontos() {
        return pontos;
    }

    public void setPontos(int pontos) {
        this.pontos = pontos;
    }

    public ECategoria getCategoria() {
        return categoria;
    }

    public void setCategoria(ECategoria categoria) {
        this.categoria = categoria;
    }

    public List<ItemOS> getItens() {
        return itens;
    }

    public double calcarServico() {
        valor = 0;
        for (ItemOS intensOS : itens){
            valor += intensOS.getValor();
        }
        return valor;
    }

    public void add(ItemOS itemOS) {
        itens.add(itemOS);
        itemOS.setServico(this);
    }

    public void remove(ItemOS itemOS) {
        itens.remove(itemOS);
        itemOS.setServico(null);
    }

}
